import { useState, useEffect } from "react";
import { Link, useLocation } from "react-router-dom";
import { Phone, Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion, AnimatePresence } from "framer-motion";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "Services", path: "/services" },
  { name: "Portfolio", path: "/portfolio" },
  { name: "About", path: "/about" },
  { name: "Contact", path: "/contact" },
];

export function Header() {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location]);

  return (
    <>
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? "bg-charcoal/95 backdrop-blur-md py-4 shadow-elegant"
            : "bg-transparent py-6"
        }`}
      >
        <div className="container-narrow flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="group">
            <div className="flex flex-col">
              <span className="text-xs tracking-widest-xl text-gold uppercase font-body">
                WHR
              </span>
              <span className="text-lg font-heading text-primary-foreground">
                General Contracting
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`underline-elegant text-sm font-body font-medium tracking-wide transition-colors ${
                  location.pathname === link.path
                    ? "text-gold"
                    : "text-primary-foreground/70 hover:text-primary-foreground"
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* Phone CTA */}
          <div className="hidden md:flex items-center gap-4">
            <a
              href="tel:+18197436039"
              className="flex items-center gap-2 text-primary-foreground hover:text-gold transition-colors"
            >
              <Phone className="w-4 h-4" />
              <span className="font-body font-medium">+1 819-743-6039</span>
            </a>
            <Button variant="gold" size="sm" asChild>
              <Link to="/contact">Free Quote</Link>
            </Button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
            className="lg:hidden p-2 text-primary-foreground"
            aria-label="Toggle menu"
          >
            {isMobileMenuOpen ? (
              <X className="w-6 h-6" />
            ) : (
              <Menu className="w-6 h-6" />
            )}
          </button>
        </div>
      </header>

      {/* Mobile Menu */}
      <AnimatePresence>
        {isMobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            transition={{ duration: 0.3 }}
            className="fixed inset-0 z-40 bg-charcoal pt-24 lg:hidden"
          >
            <nav className="container-narrow flex flex-col gap-6 py-8">
              {navLinks.map((link, index) => (
                <motion.div
                  key={link.path}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: index * 0.1 }}
                >
                  <Link
                    to={link.path}
                    className={`text-2xl font-heading ${
                      location.pathname === link.path
                        ? "text-gold"
                        : "text-primary-foreground"
                    }`}
                  >
                    {link.name}
                  </Link>
                </motion.div>
              ))}
              <div className="gold-line my-4" />
              <a
                href="tel:+18197436039"
                className="flex items-center gap-3 text-gold text-xl font-body"
              >
                <Phone className="w-5 h-5" />
                +1 819-743-6039
              </a>
              <Button variant="gold" size="lg" className="mt-4" asChild>
                <Link to="/contact">Get Free Quote</Link>
              </Button>
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
