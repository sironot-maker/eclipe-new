import { Phone } from "lucide-react";
import { motion } from "framer-motion";

export function MobileCallButton() {
  return (
    <motion.a
      href="tel:+18197436039"
      initial={{ y: 100, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 1, duration: 0.5 }}
      className="fixed bottom-6 right-6 z-50 md:hidden flex items-center gap-2 bg-gold text-charcoal px-5 py-4 rounded-full shadow-gold font-body font-semibold text-sm animate-gold-pulse"
    >
      <Phone className="w-5 h-5" />
      <span>Call Now</span>
    </motion.a>
  );
}
