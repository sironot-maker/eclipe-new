import { Link } from "react-router-dom";
import { Phone, Mail, Facebook, MapPin } from "lucide-react";

const quickLinks = [
  { name: "About", path: "/about" },
  { name: "Services", path: "/services" },
  { name: "Portfolio", path: "/portfolio" },
  { name: "Reviews", path: "/reviews" },
  { name: "FAQ", path: "/faq" },
  { name: "Contact", path: "/contact" },
];

const services = [
  { name: "Kitchen Remodeling", path: "/services/kitchen-remodeling" },
  { name: "Bathroom Renovations", path: "/services/bathroom-renovations" },
  { name: "Basement Finishing", path: "/services/basement-finishing" },
  { name: "Full Home Renovations", path: "/services/full-home-renovations" },
  { name: "Custom Additions", path: "/services/custom-additions" },
];

const serviceAreas = [
  "Ottawa",
  "Kanata",
  "Orleans",
  "Barrhaven",
  "Nepean",
  "Gatineau",
];

export function Footer() {
  return (
    <footer className="bg-charcoal text-primary-foreground">
      {/* Main Footer */}
      <div className="container-narrow section-padding">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 lg:gap-8">
          {/* Company Info */}
          <div className="lg:col-span-1">
            <div className="mb-6">
              <span className="text-xs tracking-widest-xl text-gold uppercase font-body block mb-1">
                WHR
              </span>
              <span className="text-xl font-heading text-primary-foreground">
                General Contracting
              </span>
            </div>
            <p className="text-primary-foreground/60 text-sm leading-relaxed mb-6 font-body">
              Creating lovable living spaces through expert craftsmanship and personalized service in Ottawa.
            </p>
            <div className="space-y-3">
              <a
                href="tel:+18197436039"
                className="flex items-center gap-3 text-primary-foreground hover:text-gold transition-colors group"
              >
                <Phone className="w-4 h-4 text-gold" />
                <span className="font-body">+1 819-743-6039</span>
              </a>
              <a
                href="mailto:Whrinc.gc@gmail.com"
                className="flex items-center gap-3 text-primary-foreground hover:text-gold transition-colors"
              >
                <Mail className="w-4 h-4 text-gold" />
                <span className="font-body text-sm">Whrinc.gc@gmail.com</span>
              </a>
              <div className="flex items-center gap-3 text-primary-foreground/60">
                <MapPin className="w-4 h-4 text-gold" />
                <span className="font-body text-sm">Ottawa & Surrounding Areas</span>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="font-heading text-lg mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link) => (
                <li key={link.path}>
                  <Link
                    to={link.path}
                    className="text-primary-foreground/60 hover:text-gold transition-colors text-sm font-body"
                  >
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="font-heading text-lg mb-6">Services</h4>
            <ul className="space-y-3">
              {services.map((service) => (
                <li key={service.path}>
                  <Link
                    to={service.path}
                    className="text-primary-foreground/60 hover:text-gold transition-colors text-sm font-body"
                  >
                    {service.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Service Areas */}
          <div>
            <h4 className="font-heading text-lg mb-6">Service Areas</h4>
            <ul className="space-y-3">
              {serviceAreas.map((area) => (
                <li key={area}>
                  <span className="text-primary-foreground/60 text-sm font-body">
                    {area}
                  </span>
                </li>
              ))}
            </ul>
            {/* Social */}
            <div className="mt-8">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-primary-foreground/60 hover:text-gold transition-colors"
              >
                <Facebook className="w-5 h-5" />
                <span className="text-sm font-body">Follow us</span>
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-primary-foreground/10">
        <div className="container-narrow py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <p className="text-primary-foreground/40 text-sm font-body">
            © 2025 WHR General Contracting. All rights reserved.
          </p>
          <div className="flex items-center gap-6">
            <Link
              to="/privacy"
              className="text-primary-foreground/40 hover:text-primary-foreground/60 text-sm font-body transition-colors"
            >
              Privacy Policy
            </Link>
            <Link
              to="/terms"
              className="text-primary-foreground/40 hover:text-primary-foreground/60 text-sm font-body transition-colors"
            >
              Terms of Service
            </Link>
          </div>
        </div>
      </div>
    </footer>
  );
}
