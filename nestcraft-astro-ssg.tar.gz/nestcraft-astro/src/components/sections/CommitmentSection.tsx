import { motion } from "framer-motion";

export function CommitmentSection() {
  return (
    <section className="relative py-20 md:py-28 overflow-hidden">
      {/* Gold accent background */}
      <div className="absolute inset-0 bg-gradient-to-r from-gold/10 via-gold/5 to-gold/10" />
      
      <div className="container-narrow relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center max-w-3xl mx-auto"
        >
          <span className="text-gold text-xs tracking-widest-xl uppercase font-body mb-4 block">
            Our Promise
          </span>
          <h2 className="font-heading text-3xl md:text-h1 text-foreground mb-6">
            Our Commitment to You
          </h2>
          <p className="text-muted-foreground font-body text-lg leading-relaxed">
            WHR General Contracting stands behind every project with our commitment to quality craftsmanship and customer satisfaction. We ensure transparent communication, end-to-end project management, and results you'll truly love coming home to. Your dream home deserves nothing less.
          </p>
          
          {/* Decorative gold line */}
          <div className="w-24 h-px bg-gold mx-auto mt-10" />
        </motion.div>
      </div>
    </section>
  );
}
