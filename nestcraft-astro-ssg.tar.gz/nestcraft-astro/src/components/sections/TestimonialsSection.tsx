import { motion } from "framer-motion";
import { Star, Quote } from "lucide-react";

const testimonials = [
  {
    quote: "WHR transformed our outdated kitchen into a stunning, functional space. Their attention to detail and communication throughout the project was exceptional.",
    name: "Sarah M.",
    project: "Kitchen Renovation",
    location: "Ottawa",
  },
  {
    quote: "From start to finish, the team was professional and delivered on time. Our basement is now the favorite room in the house. Highly recommend!",
    name: "Michael R.",
    project: "Basement Finishing",
    location: "Kanata",
  },
  {
    quote: "Expert craftsmanship and genuine care for our vision. They made the renovation process stress-free and the results exceeded our expectations.",
    name: "Jennifer L.",
    project: "Bathroom Renovation",
    location: "Orleans",
  },
];

export function TestimonialsSection() {
  return (
    <section className="section-padding bg-muted">
      <div className="container-narrow">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-gold text-xs tracking-widest-xl uppercase font-body mb-4 block">
            Testimonials
          </span>
          <h2 className="font-heading text-3xl md:text-h1 text-foreground mb-4">
            What Our Clients Say
          </h2>
        </motion.div>

        {/* Testimonials Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {testimonials.map((testimonial, index) => (
            <motion.div
              key={testimonial.name}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="bg-background p-8 rounded-sm shadow-soft"
            >
              {/* Stars */}
              <div className="flex gap-1 mb-4">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-4 h-4 fill-gold text-gold" />
                ))}
              </div>

              {/* Quote Icon */}
              <Quote className="w-8 h-8 text-gold/20 mb-4" />

              {/* Quote Text */}
              <p className="text-foreground font-body text-sm leading-relaxed mb-6">
                "{testimonial.quote}"
              </p>

              {/* Author */}
              <div className="border-t border-border pt-4">
                <p className="font-heading text-foreground">{testimonial.name}</p>
                <p className="text-muted-foreground text-sm font-body">
                  {testimonial.project}, {testimonial.location}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
