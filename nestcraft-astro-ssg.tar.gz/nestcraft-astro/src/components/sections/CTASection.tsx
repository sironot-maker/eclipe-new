import { Link } from "react-router-dom";
import { Phone, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export function CTASection() {
  return (
    <section className="bg-charcoal section-padding">
      <div className="container-narrow">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center"
        >
          <h2 className="font-heading text-3xl md:text-h1 text-primary-foreground mb-4">
            Ready to Transform Your Home?
          </h2>
          <p className="text-primary-foreground/60 font-body mb-10 max-w-xl mx-auto">
            Call our Ottawa team for a free consultation and personalized quote.
          </p>

          {/* Contact Info */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 mb-10">
            <a
              href="tel:+18197436039"
              className="flex items-center gap-3 text-gold text-2xl md:text-3xl font-heading hover:text-gold-light transition-colors"
            >
              <Phone className="w-6 h-6" />
              +1 819-743-6039
            </a>
          </div>

          <a
            href="mailto:Whrinc.gc@gmail.com"
            className="inline-flex items-center gap-2 text-primary-foreground/60 hover:text-primary-foreground transition-colors font-body mb-10"
          >
            <Mail className="w-4 h-4" />
            Whrinc.gc@gmail.com
          </a>

          {/* CTA Button */}
          <div className="mt-8">
            <Button variant="gold" size="lg" asChild>
              <Link to="/contact">Request Free Consultation</Link>
            </Button>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
