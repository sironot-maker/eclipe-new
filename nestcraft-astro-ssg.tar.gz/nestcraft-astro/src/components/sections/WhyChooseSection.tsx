import { motion } from "framer-motion";
import { Palette, ClipboardCheck, Award, Users, Target, MapPin } from "lucide-react";

const differentiators = [
  {
    icon: Palette,
    title: "Customized Transformations",
    description: "Tailored designs for kitchens, bathrooms, and basements that blend functionality with modern style.",
  },
  {
    icon: ClipboardCheck,
    title: "End-to-End Management",
    description: "Expert handling of projects from initial concept to final inspection, ensuring work stays on time and on budget.",
  },
  {
    icon: Award,
    title: "Expert Craftsmanship",
    description: "Detail-oriented work and durable quality that increases both market value and daily enjoyment of your home.",
  },
  {
    icon: Users,
    title: "Client-Centered Approach",
    description: "Transparent communication and honest service designed to make the renovation process stress-free.",
  },
  {
    icon: Target,
    title: "Precision Project Management",
    description: "Meticulous planning and execution to deliver results you'll love coming home to.",
  },
  {
    icon: MapPin,
    title: "Local Ottawa Team",
    description: "Fast response, local knowledge, and a community reputation built on trust and quality.",
  },
];

export function WhyChooseSection() {
  return (
    <section className="section-padding bg-muted">
      <div className="container-narrow">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-gold text-xs tracking-widest-xl uppercase font-body mb-4 block">
            Why WHR
          </span>
          <h2 className="font-heading text-3xl md:text-h1 text-foreground mb-4 text-balance">
            Why Ottawa Homeowners Trust <br className="hidden md:block" />
            WHR General Contracting
          </h2>
        </motion.div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {differentiators.map((item, index) => (
            <motion.div
              key={item.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.5, delay: index * 0.1 }}
              className="flex gap-5"
            >
              <div className="flex-shrink-0 w-12 h-12 rounded-full bg-gold/10 flex items-center justify-center">
                <item.icon className="w-5 h-5 text-gold" />
              </div>
              <div>
                <h3 className="font-heading text-lg text-foreground mb-2">
                  {item.title}
                </h3>
                <p className="text-muted-foreground font-body text-sm leading-relaxed">
                  {item.description}
                </p>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
