import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ChefHat, Bath, Home, Building2, PlusSquare, Expand, ArrowRight } from "lucide-react";

const services = [
  {
    icon: ChefHat,
    title: "Kitchen Remodeling",
    description: "Custom designs that blend functionality with modern elegance for the heart of your home.",
    path: "/services/kitchen-remodeling",
  },
  {
    icon: Bath,
    title: "Bathroom Renovations",
    description: "Spa-quality transformations for your daily retreat with luxury finishes.",
    path: "/services/bathroom-renovations",
  },
  {
    icon: Home,
    title: "Basement Finishing",
    description: "Unlock your home's potential with expert conversions for entertainment or living space.",
    path: "/services/basement-finishing",
  },
  {
    icon: Building2,
    title: "Full Home Renovations",
    description: "Complete transformations from concept to completion with cohesive design.",
    path: "/services/full-home-renovations",
  },
  {
    icon: PlusSquare,
    title: "Custom Additions",
    description: "Expand your living space seamlessly with expertly designed room additions.",
    path: "/services/custom-additions",
  },
  {
    icon: Expand,
    title: "Home Extensions",
    description: "Grow your home without the hassle of moving through structural expansions.",
    path: "/services/home-extensions",
  },
];

const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: {
      staggerChildren: 0.1,
    },
  },
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5 },
  },
};

export function ServicesSection() {
  return (
    <section className="section-padding bg-background">
      <div className="container-narrow">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-gold text-xs tracking-widest-xl uppercase font-body mb-4 block">
            Our Expertise
          </span>
          <h2 className="font-heading text-3xl md:text-h1 text-foreground mb-4">
            Transform Your Home
          </h2>
          <p className="text-muted-foreground font-body max-w-2xl mx-auto">
            End-to-end renovation services with expert craftsmanship and personalized attention to every detail.
          </p>
        </motion.div>

        {/* Services Grid */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {services.map((service) => (
            <motion.div key={service.title} variants={itemVariants}>
              <Link
                to={service.path}
                className="card-elegant group flex flex-col p-8 h-full"
              >
                <div className="w-12 h-12 rounded-sm bg-muted flex items-center justify-center mb-6 group-hover:bg-gold/10 transition-colors">
                  <service.icon className="w-6 h-6 text-gold" />
                </div>
                <h3 className="font-heading text-xl text-foreground mb-3">
                  {service.title}
                </h3>
                <p className="text-muted-foreground font-body text-sm leading-relaxed flex-grow mb-4">
                  {service.description}
                </p>
                <div className="flex items-center gap-2 text-gold text-sm font-body font-medium group-hover:gap-3 transition-all">
                  <span>Explore</span>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </Link>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </section>
  );
}
