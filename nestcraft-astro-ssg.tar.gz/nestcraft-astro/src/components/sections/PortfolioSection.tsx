import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { Button } from "@/components/ui/button";
import kitchenImage from "@/assets/kitchen-bright.jpg";
import bathroomImage from "@/assets/bathroom-luxury.jpg";
import basementImage from "@/assets/basement-luxury.jpg";

const projects = [
  {
    title: "Kitchen Transformations",
    category: "Kitchen Remodeling",
    image: kitchenImage,
    location: "Ottawa",
  },
  {
    title: "Luxury Bathrooms",
    category: "Bathroom Renovation",
    image: bathroomImage,
    location: "Kanata",
  },
  {
    title: "Basement Living Spaces",
    category: "Basement Finishing",
    image: basementImage,
    location: "Orleans",
  },
];

export function PortfolioSection() {
  return (
    <section className="section-padding bg-background">
      <div className="container-narrow">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6 }}
          className="text-center mb-16"
        >
          <span className="text-gold text-xs tracking-widest-xl uppercase font-body mb-4 block">
            Our Work
          </span>
          <h2 className="font-heading text-3xl md:text-h1 text-foreground mb-4">
            Projects We're Proud Of
          </h2>
          <p className="text-muted-foreground font-body max-w-2xl mx-auto">
            Browse our recent renovations showcasing expert craftsmanship and attention to detail.
          </p>
        </motion.div>

        {/* Projects Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
          {projects.map((project, index) => (
            <motion.div
              key={project.title}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: index * 0.15 }}
              className="group relative aspect-[4/5] overflow-hidden rounded-sm"
            >
              <img
                src={project.image}
                alt={project.title}
                className="absolute inset-0 w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-charcoal/90 via-charcoal/30 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6">
                <span className="text-gold text-xs tracking-widest uppercase font-body mb-2 block">
                  {project.category}
                </span>
                <h3 className="font-heading text-xl text-primary-foreground mb-1">
                  {project.title}
                </h3>
                <span className="text-primary-foreground/60 text-sm font-body">
                  {project.location}
                </span>
              </div>
            </motion.div>
          ))}
        </div>

        {/* CTA */}
        <motion.div
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.3 }}
          className="text-center"
        >
          <Button variant="outline" size="lg" asChild>
            <Link to="/portfolio" className="gap-2">
              View Full Portfolio
              <ArrowRight className="w-4 h-4" />
            </Link>
          </Button>
        </motion.div>
      </div>
    </section>
  );
}
