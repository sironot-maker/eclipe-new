import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { MobileCallButton } from "@/components/MobileCallButton";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, Clock, Send } from "lucide-react";
import { useState } from "react";

const serviceOptions = [
  "Kitchen Remodeling",
  "Bathroom Renovation",
  "Basement Finishing",
  "Full Home Renovation",
  "Custom Addition",
  "Home Extension",
  "Other / Multiple Services",
];

const timelineOptions = [
  "As soon as possible",
  "Within 1-2 months",
  "3-6 months",
  "6-12 months",
  "Just planning / gathering quotes",
];

const locationOptions = [
  "Ottawa",
  "Kanata",
  "Orleans",
  "Barrhaven",
  "Nepean",
  "Gloucester",
  "Gatineau",
  "Hull",
  "Other",
];

const Contact = () => {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    service: "",
    timeline: "",
    location: "",
    firstName: "",
    lastName: "",
    phone: "",
    email: "",
    preferredContact: "phone",
    details: "",
    consent: false,
  });
  const [submitted, setSubmitted] = useState(false);

  const handleNext = () => {
    if (step < 4) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // In a real app, this would send to backend
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <div className="min-h-screen">
        <Header />
        <main className="pt-32 pb-20">
          <div className="container-narrow">
            <motion.div
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              className="max-w-xl mx-auto text-center bg-muted p-12 rounded-sm"
            >
              <div className="w-16 h-16 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-6">
                <Send className="w-8 h-8 text-gold" />
              </div>
              <h1 className="font-heading text-3xl text-foreground mb-4">
                Consultation Request Received!
              </h1>
              <p className="text-muted-foreground font-body mb-8">
                Thank you for choosing WHR General Contracting. Our team will review your project and contact you within 24 hours.
              </p>
              <div className="space-y-4 text-left bg-background p-6 rounded-sm mb-8">
                <p className="text-sm text-muted-foreground font-body">For immediate assistance:</p>
                <a href="tel:+18197436039" className="flex items-center gap-3 text-foreground hover:text-gold transition-colors">
                  <Phone className="w-4 h-4 text-gold" />
                  <span className="font-body">+1 819-743-6039</span>
                </a>
                <a href="mailto:Whrinc.gc@gmail.com" className="flex items-center gap-3 text-foreground hover:text-gold transition-colors">
                  <Mail className="w-4 h-4 text-gold" />
                  <span className="font-body">Whrinc.gc@gmail.com</span>
                </a>
              </div>
            </motion.div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-16 bg-charcoal">
          <div className="container-narrow text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-gold text-xs tracking-widest-xl uppercase font-body mb-4 block">
                Get In Touch
              </span>
              <h1 className="font-heading text-4xl md:text-display-sm text-primary-foreground mb-6">
                Start Your Transformation
              </h1>
              <p className="text-primary-foreground/70 font-body max-w-2xl mx-auto">
                Request a free consultation and let's discuss your vision.
              </p>
            </motion.div>
          </div>
        </section>

        <section className="section-padding bg-background">
          <div className="container-narrow">
            <div className="grid lg:grid-cols-3 gap-12">
              {/* Contact Info */}
              <div className="lg:col-span-1">
                <h2 className="font-heading text-2xl text-foreground mb-6">
                  Contact Information
                </h2>
                <div className="space-y-6">
                  <a
                    href="tel:+18197436039"
                    className="flex items-start gap-4 group"
                  >
                    <div className="w-10 h-10 bg-gold/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Phone className="w-4 h-4 text-gold" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground font-body mb-1">Phone</p>
                      <p className="font-heading text-foreground group-hover:text-gold transition-colors">
                        +1 819-743-6039
                      </p>
                    </div>
                  </a>

                  <a
                    href="mailto:Whrinc.gc@gmail.com"
                    className="flex items-start gap-4 group"
                  >
                    <div className="w-10 h-10 bg-gold/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Mail className="w-4 h-4 text-gold" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground font-body mb-1">Email</p>
                      <p className="font-heading text-foreground group-hover:text-gold transition-colors">
                        Whrinc.gc@gmail.com
                      </p>
                    </div>
                  </a>

                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-gold/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-4 h-4 text-gold" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground font-body mb-1">Service Area</p>
                      <p className="font-heading text-foreground">
                        Ottawa & Surrounding Areas
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-4">
                    <div className="w-10 h-10 bg-gold/10 rounded-full flex items-center justify-center flex-shrink-0">
                      <Clock className="w-4 h-4 text-gold" />
                    </div>
                    <div>
                      <p className="text-sm text-muted-foreground font-body mb-1">Response Time</p>
                      <p className="font-heading text-foreground">
                        Within 24 hours
                      </p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Form */}
              <div className="lg:col-span-2">
                <div className="bg-muted p-8 md:p-10 rounded-sm">
                  {/* Progress */}
                  <div className="flex items-center gap-2 mb-8">
                    {[1, 2, 3, 4].map((s) => (
                      <div
                        key={s}
                        className={`h-1 flex-1 rounded-full transition-colors ${
                          s <= step ? "bg-gold" : "bg-border"
                        }`}
                      />
                    ))}
                  </div>

                  <form onSubmit={handleSubmit}>
                    {/* Step 1: Service */}
                    {step === 1 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <h3 className="font-heading text-xl text-foreground mb-2">
                          What service are you interested in?
                        </h3>
                        <p className="text-muted-foreground text-sm font-body mb-6">
                          Select the type of renovation you're considering.
                        </p>
                        <div className="grid gap-3">
                          {serviceOptions.map((option) => (
                            <label
                              key={option}
                              className={`flex items-center gap-3 p-4 rounded-sm border cursor-pointer transition-all ${
                                formData.service === option
                                  ? "border-gold bg-gold/5"
                                  : "border-border hover:border-gold/50"
                              }`}
                            >
                              <input
                                type="radio"
                                name="service"
                                value={option}
                                checked={formData.service === option}
                                onChange={(e) =>
                                  setFormData({ ...formData, service: e.target.value })
                                }
                                className="sr-only"
                              />
                              <div
                                className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                                  formData.service === option
                                    ? "border-gold"
                                    : "border-muted-foreground"
                                }`}
                              >
                                {formData.service === option && (
                                  <div className="w-2 h-2 rounded-full bg-gold" />
                                )}
                              </div>
                              <span className="font-body text-foreground">{option}</span>
                            </label>
                          ))}
                        </div>
                        <div className="mt-8 flex justify-end">
                          <Button
                            type="button"
                            variant="gold"
                            onClick={handleNext}
                            disabled={!formData.service}
                          >
                            Continue
                          </Button>
                        </div>
                      </motion.div>
                    )}

                    {/* Step 2: Timeline */}
                    {step === 2 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <h3 className="font-heading text-xl text-foreground mb-2">
                          When would you like to start?
                        </h3>
                        <p className="text-muted-foreground text-sm font-body mb-6">
                          This helps us plan and prioritize your project.
                        </p>
                        <div className="grid gap-3">
                          {timelineOptions.map((option) => (
                            <label
                              key={option}
                              className={`flex items-center gap-3 p-4 rounded-sm border cursor-pointer transition-all ${
                                formData.timeline === option
                                  ? "border-gold bg-gold/5"
                                  : "border-border hover:border-gold/50"
                              }`}
                            >
                              <input
                                type="radio"
                                name="timeline"
                                value={option}
                                checked={formData.timeline === option}
                                onChange={(e) =>
                                  setFormData({ ...formData, timeline: e.target.value })
                                }
                                className="sr-only"
                              />
                              <div
                                className={`w-4 h-4 rounded-full border-2 flex items-center justify-center ${
                                  formData.timeline === option
                                    ? "border-gold"
                                    : "border-muted-foreground"
                                }`}
                              >
                                {formData.timeline === option && (
                                  <div className="w-2 h-2 rounded-full bg-gold" />
                                )}
                              </div>
                              <span className="font-body text-foreground">{option}</span>
                            </label>
                          ))}
                        </div>
                        <div className="mt-8 flex justify-between">
                          <Button type="button" variant="ghost" onClick={handleBack}>
                            Back
                          </Button>
                          <Button
                            type="button"
                            variant="gold"
                            onClick={handleNext}
                            disabled={!formData.timeline}
                          >
                            Continue
                          </Button>
                        </div>
                      </motion.div>
                    )}

                    {/* Step 3: Location */}
                    {step === 3 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <h3 className="font-heading text-xl text-foreground mb-2">
                          Where is your property located?
                        </h3>
                        <p className="text-muted-foreground text-sm font-body mb-6">
                          We serve Ottawa and surrounding areas.
                        </p>
                        <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                          {locationOptions.map((option) => (
                            <label
                              key={option}
                              className={`flex items-center justify-center p-4 rounded-sm border cursor-pointer transition-all text-center ${
                                formData.location === option
                                  ? "border-gold bg-gold/5"
                                  : "border-border hover:border-gold/50"
                              }`}
                            >
                              <input
                                type="radio"
                                name="location"
                                value={option}
                                checked={formData.location === option}
                                onChange={(e) =>
                                  setFormData({ ...formData, location: e.target.value })
                                }
                                className="sr-only"
                              />
                              <span className="font-body text-foreground">{option}</span>
                            </label>
                          ))}
                        </div>
                        <div className="mt-8 flex justify-between">
                          <Button type="button" variant="ghost" onClick={handleBack}>
                            Back
                          </Button>
                          <Button
                            type="button"
                            variant="gold"
                            onClick={handleNext}
                            disabled={!formData.location}
                          >
                            Final Step
                          </Button>
                        </div>
                      </motion.div>
                    )}

                    {/* Step 4: Contact Info */}
                    {step === 4 && (
                      <motion.div
                        initial={{ opacity: 0, x: 20 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ duration: 0.3 }}
                      >
                        <h3 className="font-heading text-xl text-foreground mb-2">
                          How should we contact you?
                        </h3>
                        <p className="text-muted-foreground text-sm font-body mb-6">
                          We'll reach out within 24 hours to schedule your consultation.
                        </p>
                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label className="text-sm font-body text-foreground mb-2 block">
                              First Name *
                            </label>
                            <input
                              type="text"
                              required
                              value={formData.firstName}
                              onChange={(e) =>
                                setFormData({ ...formData, firstName: e.target.value })
                              }
                              className="w-full px-4 py-3 rounded-sm border border-border bg-background font-body focus:border-gold focus:outline-none transition-colors"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-body text-foreground mb-2 block">
                              Last Name *
                            </label>
                            <input
                              type="text"
                              required
                              value={formData.lastName}
                              onChange={(e) =>
                                setFormData({ ...formData, lastName: e.target.value })
                              }
                              className="w-full px-4 py-3 rounded-sm border border-border bg-background font-body focus:border-gold focus:outline-none transition-colors"
                            />
                          </div>
                        </div>
                        <div className="grid md:grid-cols-2 gap-4 mb-4">
                          <div>
                            <label className="text-sm font-body text-foreground mb-2 block">
                              Phone Number *
                            </label>
                            <input
                              type="tel"
                              required
                              value={formData.phone}
                              onChange={(e) =>
                                setFormData({ ...formData, phone: e.target.value })
                              }
                              placeholder="+1 (819) XXX-XXXX"
                              className="w-full px-4 py-3 rounded-sm border border-border bg-background font-body focus:border-gold focus:outline-none transition-colors"
                            />
                          </div>
                          <div>
                            <label className="text-sm font-body text-foreground mb-2 block">
                              Email Address *
                            </label>
                            <input
                              type="email"
                              required
                              value={formData.email}
                              onChange={(e) =>
                                setFormData({ ...formData, email: e.target.value })
                              }
                              className="w-full px-4 py-3 rounded-sm border border-border bg-background font-body focus:border-gold focus:outline-none transition-colors"
                            />
                          </div>
                        </div>
                        <div className="mb-4">
                          <label className="text-sm font-body text-foreground mb-2 block">
                            Additional Details (Optional)
                          </label>
                          <textarea
                            value={formData.details}
                            onChange={(e) =>
                              setFormData({ ...formData, details: e.target.value })
                            }
                            rows={3}
                            maxLength={500}
                            placeholder="Tell us about your project vision..."
                            className="w-full px-4 py-3 rounded-sm border border-border bg-background font-body focus:border-gold focus:outline-none transition-colors resize-none"
                          />
                        </div>
                        <label className="flex items-start gap-3 mb-8 cursor-pointer">
                          <input
                            type="checkbox"
                            checked={formData.consent}
                            onChange={(e) =>
                              setFormData({ ...formData, consent: e.target.checked })
                            }
                            className="mt-1"
                          />
                          <span className="text-sm font-body text-muted-foreground">
                            I agree to be contacted by WHR General Contracting regarding my consultation request.
                          </span>
                        </label>
                        <div className="flex justify-between">
                          <Button type="button" variant="ghost" onClick={handleBack}>
                            Back
                          </Button>
                          <Button
                            type="submit"
                            variant="gold"
                            size="lg"
                            disabled={
                              !formData.firstName ||
                              !formData.lastName ||
                              !formData.phone ||
                              !formData.email ||
                              !formData.consent
                            }
                          >
                            Get My Free Consultation
                          </Button>
                        </div>
                      </motion.div>
                    )}
                  </form>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <MobileCallButton />
    </div>
  );
};

export default Contact;
