import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { MobileCallButton } from "@/components/MobileCallButton";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Phone, Mail, MapPin, Clock, ArrowRight } from "lucide-react";

const services = [
  {
    title: "Kitchen Remodeling",
    description: "Custom designs that blend functionality with modern elegance. From layout optimization to premium finishes.",
    path: "/services/kitchen-remodeling",
  },
  {
    title: "Bathroom Renovations",
    description: "Spa-quality transformations with luxury fixtures, modern layouts, and accessibility improvements.",
    path: "/services/bathroom-renovations",
  },
  {
    title: "Basement Finishing",
    description: "Unlock hidden potential with entertainment spaces, home offices, or additional living areas.",
    path: "/services/basement-finishing",
  },
  {
    title: "Full Home Renovations",
    description: "Complete whole-house transformations with cohesive design from concept to completion.",
    path: "/services/full-home-renovations",
  },
  {
    title: "Custom Additions",
    description: "Seamless room extensions, second-story additions, and sunroom installations.",
    path: "/services/custom-additions",
  },
  {
    title: "Home Extensions",
    description: "Expand your living space with structural additions that maintain architectural harmony.",
    path: "/services/home-extensions",
  },
];

const Services = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-20 bg-charcoal">
          <div className="container-narrow text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-gold text-xs tracking-widest-xl uppercase font-body mb-4 block">
                Our Services
              </span>
              <h1 className="font-heading text-4xl md:text-display-sm text-primary-foreground mb-6">
                Premium Renovation Services
              </h1>
              <p className="text-primary-foreground/70 font-body max-w-2xl mx-auto text-lg">
                End-to-end project management with expert craftsmanship for every renovation need.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Services List */}
        <section className="section-padding bg-background">
          <div className="container-narrow">
            <div className="grid gap-8">
              {services.map((service, index) => (
                <motion.div
                  key={service.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                >
                  <Link
                    to={service.path}
                    className="card-elegant group flex flex-col md:flex-row md:items-center justify-between p-8 gap-6"
                  >
                    <div className="flex-1">
                      <h2 className="font-heading text-2xl text-foreground mb-3 group-hover:text-gold transition-colors">
                        {service.title}
                      </h2>
                      <p className="text-muted-foreground font-body">
                        {service.description}
                      </p>
                    </div>
                    <div className="flex items-center gap-2 text-gold font-body font-medium group-hover:gap-4 transition-all">
                      <span>Learn More</span>
                      <ArrowRight className="w-5 h-5" />
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="bg-muted section-padding">
          <div className="container-narrow text-center">
            <h2 className="font-heading text-3xl text-foreground mb-6">
              Ready to Start Your Project?
            </h2>
            <p className="text-muted-foreground font-body mb-8 max-w-xl mx-auto">
              Contact us for a free consultation and personalized quote.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button variant="gold" size="lg" asChild>
                <a href="tel:+18197436039" className="gap-2">
                  <Phone className="w-5 h-5" />
                  Call +1 819-743-6039
                </a>
              </Button>
              <Button variant="outline" size="lg" asChild>
                <Link to="/contact">Get Free Quote</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <MobileCallButton />
    </div>
  );
};

export default Services;
