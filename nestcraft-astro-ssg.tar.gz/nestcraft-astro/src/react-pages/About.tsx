import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { MobileCallButton } from "@/components/MobileCallButton";
import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { motion } from "framer-motion";
import { Phone, Award, Users, Target, Heart } from "lucide-react";

const values = [
  {
    icon: Award,
    title: "Expert Craftsmanship",
    description: "Every project reflects our commitment to quality and attention to detail.",
  },
  {
    icon: Users,
    title: "Client-Centered",
    description: "Your vision guides our work. We listen, collaborate, and deliver.",
  },
  {
    icon: Target,
    title: "Precision",
    description: "Meticulous planning ensures on-time, on-budget completion.",
  },
  {
    icon: Heart,
    title: "Passion",
    description: "We love transforming houses into homes people love.",
  },
];

const About = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        {/* Hero */}
        <section className="pt-32 pb-20 bg-charcoal">
          <div className="container-narrow text-center">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
            >
              <span className="text-gold text-xs tracking-widest-xl uppercase font-body mb-4 block">
                About WHR
              </span>
              <h1 className="font-heading text-4xl md:text-display-sm text-primary-foreground mb-6">
                Creating Lovable Living Spaces
              </h1>
              <p className="text-primary-foreground/70 font-body max-w-2xl mx-auto text-lg">
                Your trusted partner for premium home renovations in Ottawa and surrounding areas.
              </p>
            </motion.div>
          </div>
        </section>

        {/* Story */}
        <section className="section-padding bg-background">
          <div className="container-narrow">
            <div className="max-w-3xl mx-auto">
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6 }}
              >
                <h2 className="font-heading text-3xl text-foreground mb-6 text-center">
                  Our Story
                </h2>
                <div className="prose prose-lg font-body text-muted-foreground space-y-6">
                  <p>
                    WHR General Contracting was founded with a simple mission: to transform ordinary houses into extraordinary homes that families truly love. Based in Ottawa, we've built our reputation on expert craftsmanship, transparent communication, and an unwavering commitment to customer satisfaction.
                  </p>
                  <p>
                    What sets us apart is our end-to-end approach to project management. From the initial consultation to the final walkthrough, we handle every aspect of your renovation with meticulous care. We understand that a home renovation is more than just a construction project—it's an investment in your family's comfort and quality of life.
                  </p>
                  <p>
                    Our team brings together experienced craftsmen, designers, and project managers who share a passion for creating beautiful, functional spaces. Whether you're dreaming of a modern kitchen, a spa-like bathroom, or a complete home transformation, we have the expertise to bring your vision to life.
                  </p>
                  <p>
                    Every project we undertake reflects our core values: precision, integrity, and personalized service. We believe that the renovation process should be as enjoyable as the finished result, which is why we prioritize clear communication and collaborative decision-making throughout.
                  </p>
                </div>
              </motion.div>
            </div>
          </div>
        </section>

        {/* Values */}
        <section className="section-padding bg-muted">
          <div className="container-narrow">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="text-center mb-12"
            >
              <h2 className="font-heading text-3xl text-foreground mb-4">
                Our Values
              </h2>
              <p className="text-muted-foreground font-body max-w-xl mx-auto">
                The principles that guide every project we undertake.
              </p>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
              {values.map((value, index) => (
                <motion.div
                  key={value.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: index * 0.1 }}
                  className="text-center"
                >
                  <div className="w-14 h-14 bg-gold/10 rounded-full flex items-center justify-center mx-auto mb-4">
                    <value.icon className="w-6 h-6 text-gold" />
                  </div>
                  <h3 className="font-heading text-lg text-foreground mb-2">
                    {value.title}
                  </h3>
                  <p className="text-muted-foreground font-body text-sm">
                    {value.description}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA */}
        <section className="bg-charcoal section-padding">
          <div className="container-narrow text-center">
            <h2 className="font-heading text-3xl text-primary-foreground mb-6">
              Let's Build Something Beautiful Together
            </h2>
            <p className="text-primary-foreground/60 font-body mb-8 max-w-xl mx-auto">
              Contact us today for a free consultation and personalized quote.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Button variant="gold" size="lg" asChild>
                <a href="tel:+18197436039" className="gap-2">
                  <Phone className="w-5 h-5" />
                  Call +1 819-743-6039
                </a>
              </Button>
              <Button variant="heroOutline" size="lg" asChild>
                <Link to="/contact">Get Free Quote</Link>
              </Button>
            </div>
          </div>
        </section>
      </main>
      <Footer />
      <MobileCallButton />
    </div>
  );
};

export default About;
