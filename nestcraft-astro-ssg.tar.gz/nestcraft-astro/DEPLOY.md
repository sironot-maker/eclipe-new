# 🚀 Quick Deployment Guide

## Deploy in 5 Minutes

### Method 1: Netlify (Recommended - FREE!)

1. **Push to GitHub**
   ```bash
   git init
   git add .
   git commit -m "Initial commit - SSG version"
   git branch -M main
   git remote add origin YOUR_GITHUB_REPO_URL
   git push -u origin main
   ```

2. **Deploy on Netlify**
   - Go to [netlify.com](https://netlify.com)
   - Click "New site from Git"
   - Choose your GitHub repo
   - Build command: `npm run build`
   - Publish directory: `dist`
   - Click "Deploy"!

3. **Done!** Your site is live in ~2 minutes.

---

### Method 2: Vercel (Also FREE!)

1. Push to GitHub (same as above)

2. Go to [vercel.com](https://vercel.com)
   - Click "Import Project"
   - Select your repo
   - Framework: Astro (auto-detected)
   - Click "Deploy"!

3. **Done!** Live in ~1 minute.

---

### Method 3: Any Web Host (Hostinger, Bluehost, etc.)

1. **Build the site locally**
   ```bash
   npm install
   npm run build
   ```

2. **Upload via FTP or cPanel**
   - The entire `dist/` folder
   - Point your domain to this folder

3. **Done!** Site is live.

---

## ⚙️ Environment Setup (First Time Only)

If you haven't deployed before:

```bash
# Install Node.js (if not installed)
# Download from: nodejs.org

# Install dependencies
npm install

# Test locally
npm run dev
# Visit: http://localhost:4321

# Build for production
npm run build

# Preview production build
npm run preview
```

---

## 🔥 All Files Included

✅ All pages (Home, Services, Portfolio, About, Contact, 404)
✅ All components (Header, Footer, Forms, Sections)
✅ All images (kitchen, bathroom, basement photos)
✅ All styles (Tailwind CSS configured)
✅ SEO ready (meta tags, sitemap, robots.txt)
✅ Multi-step form working perfectly

---

## 📞 Form Submission Setup

The contact form works client-side but needs a backend to send emails.

### Easy Option: Netlify Forms

Add this to `/src/react-components/ContactPage.tsx` in the `<form>` tag:

```tsx
<form onSubmit={handleSubmit} netlify data-netlify="true">
```

Netlify will handle submissions automatically!

### Other Options:
- **FormSpree** - formspree.io
- **EmailJS** - emailjs.com
- **Custom API** - Build your own

---

## 🎯 Your Site is Ready!

Just run:
```bash
npm install
npm run build
```

Then upload `dist/` folder to any host, or deploy to Netlify/Vercel. That's it! 🎉
